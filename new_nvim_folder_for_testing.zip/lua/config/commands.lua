-- =============================================================================
-- config/commands.lua  –  custom user commands
-- =============================================================================

vim.api.nvim_create_user_command("ToggleRelativeNumber", function()
  vim.wo.relativenumber = not vim.wo.relativenumber
end, {})

-- =============================================================================
-- config/keymaps.lua  –  plugin-free keymaps
--
-- All descriptions use [tag] prefixes so <leader>k fuzzy search is useful:
--   [win]     window / split management
--   [tab]     tab management
--   [clip]    clipboard
--   [edit]    misc editing helpers
--   [oil]     file manager (open trigger; the rest live in plugins/oilfilemanager.lua)
-- =============================================================================

local km = vim.keymap

-- =============================================================================
-- File manager (oil)
-- =============================================================================
-- Press  -  from any buffer to open oil in the parent directory of the current file.
-- If the buffer has no associated file (e.g. a terminal or scratch buffer),
-- oil opens in the current working directory instead.
--
-- We call open_float(dir) explicitly rather than the default open() to avoid
-- a Windows bug in oil's posix_to_os_path where a nil drive letter crashes
-- when oil is opened from a pathless buffer.

km.set("n", "-", function()
  local dir = vim.fn.expand("%:p:h")
  if dir == "" or dir == "." or not vim.fn.isdirectory(dir) then
    dir = vim.fn.getcwd()
  end
  require("oil").open_float(dir)
end, { desc = "[oil] open parent dir" })

-- =============================================================================
-- Misc editing
-- =============================================================================

km.set("n", "<leader>tr", ":ToggleRelativeNumber<CR>", { silent = true, desc = "[edit] toggle relative numbers" })
km.set("n", "<leader>nh", ":nohl<CR>",                 { desc = "[edit] clear search highlights" })
km.set("n", "<leader>+",  "<C-a>",                     { desc = "[edit] increment number" })
km.set("n", "<leader>-",  "<C-x>",                     { desc = "[edit] decrement number" })

-- gx: open URL or file path under the cursor with the system default application.
-- Override built-in gx just to attach the [edit] description tag.
km.set("n", "gx", function() vim.ui.open(vim.fn.expand("<cfile>")) end, { desc = "[edit] open URL/path under cursor" })
km.set("x", "gx", function() vim.ui.open(vim.fn.expand("<cfile>")) end, { desc = "[edit] open URL/path (visual)" })

-- =============================================================================
-- Window / split management
-- =============================================================================
-- Use Alt-Arrow keys to move focus between splits without leaving home row.

km.set("n", "<leader>sv", "<C-w>v",         { desc = "[win] split vertical" })
km.set("n", "<leader>sh", "<C-w>s",         { desc = "[win] split horizontal" })
km.set("n", "<leader>se", "<C-w>=",         { desc = "[win] equal splits" })
km.set("n", "<leader>sx", "<cmd>close<CR>", { desc = "[win] close split" })

km.set("n", "<M-Left>",  "<C-w>h", { desc = "[win] go left" })
km.set("n", "<M-Down>",  "<C-w>j", { desc = "[win] go down" })
km.set("n", "<M-Up>",    "<C-w>k", { desc = "[win] go up" })
km.set("n", "<M-Right>", "<C-w>l", { desc = "[win] go right" })

-- =============================================================================
-- Tab management
-- =============================================================================

km.set("n", "<leader>to", function() vim.cmd("tabnew") end,   { desc = "[tab] new" })
km.set("n", "<leader>tx", function() vim.cmd("tabclose") end, { desc = "[tab] close" })
km.set("n", "<leader>tn", "<cmd>tabn<CR>",                    { desc = "[tab] next" })
km.set("n", "<leader>tp", "<cmd>tabp<CR>",                    { desc = "[tab] prev" })
km.set("n", "<leader>tf", "<cmd>tabnew %<CR>",                { desc = "[tab] buf in new tab" })

-- =============================================================================
-- Clipboard (system register)
-- =============================================================================
-- Alt-y works as a "system yank" operator — same idea as y but copies to the
-- OS clipboard (+) instead of Neovim's default register.
--
--   <M-y> + motion   System-yank the text covered by the motion.
--                    Example:  <M-y>iw  → copy word to clipboard
--                              <M-y>3j  → copy 3 lines to clipboard
--   <M-y><M-y>       System-yank the whole line  (operator-pending "_" trick)
--   <M-Y>            System-yank from cursor to end of line  (mirrors Y)
--   <M-y> (visual)   System-yank the selection

km.set({ "n", "x" }, "<M-y>", '"+y',  { desc = "[clip] system copy" })
km.set("o",          "<M-y>", "_",    { desc = "[clip] system copy line motion" })
km.set("n",          "<M-Y>", '"+y$', { desc = "[clip] system copy to EOL" })

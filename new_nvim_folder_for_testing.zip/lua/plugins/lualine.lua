-- Lualine: fast, customisable statusline with icons and live information.
--
-- Layout (left → right across the bottom of the screen):
--   [mode]  [branch · diff · diagnostics]  filename  ···  [encoding · fileformat · filetype]  [progress]  [line:col]
--
-- globalstatus = true: one shared statusline at the bottom instead of a
-- separate bar per split window.

return {
  "nvim-lualine/lualine.nvim",
  dependencies = { "nvim-tree/nvim-web-devicons" },
  config = function()
    require("lualine").setup({
      options = {
        icons_enabled        = true,
        theme                = "kanagawa",
        component_separators = { left = "", right = "" },
        section_separators   = { left = "", right = "" },
        globalstatus         = true,  -- single bar shared by all split windows
      },
      sections = {
        lualine_a = { "mode" },                            -- NORMAL / INSERT / VISUAL …
        lualine_b = { "branch", "diff", "diagnostics" },  -- git branch, ±lines, LSP errors/warnings
        lualine_c = { "filename" },                        -- current file path
        lualine_x = { "encoding", "fileformat", "filetype" },
        lualine_y = { "progress" },                        -- percentage through the file
        lualine_z = { "location" },                        -- line:column
      },
      -- Unfocused windows show only file name and position
      inactive_sections = {
        lualine_c = { "filename" },
        lualine_x = { "location" },
      },
    })
  end,
}
